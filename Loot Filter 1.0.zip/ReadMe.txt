You've added and downloaded some custom sounds for you filter. Those sound files need to be placed in the same folder as your filter file.

This is a list of all used custom sounds:
- gold.wav
- Maven_colleciton.ogg
- potiondrink.wav
- 3uniques.mp3
- ring.wav
- rune.wav
- 6veryvaluable.mp3
- TimeLost.wav
- gem.wav
- Stefan Gold_1maybevaluable.mp3
- Stefan Gold_placeholder.mp3
- Stefan Gold_3uniques.mp3
- 4maps.mp3
- Epic Sound.wav
- Artifact.wav
- Catalystl.wav
- S Essense.wav
- S Omen.wav
- Stefan Gold_12leveling.mp3
- LogBook.wav
- Splinter.wav
- Stefan Gold_6veryvaluable.mp3
- Ascendancy.wav
- 2currency.mp3
- S Uniques.wav
